package com.chinasoft.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;

import com.chinasoft.dao.RegionDAO;
import com.chinasoft.pojo.EnterpriseUsers;
import com.chinasoft.pojo.HouseBuyRent;
import com.chinasoft.pojo.HouseBuyRequest;
import com.chinasoft.pojo.HouseSellEnterprise;
import com.chinasoft.pojo.HouseSellRent;
import com.chinasoft.pojo.HouseSellSecondhand;
import com.chinasoft.pojo.Users;
import com.chinasoft.service.HouseBuyRentService;
import com.chinasoft.service.HouseBuyRequestService;
import com.chinasoft.service.HouseSellEnterpriseService;
import com.chinasoft.service.HouseSellRentService;
import com.chinasoft.service.HouseSellSecondhandService;
import com.chinasoft.service.HouseTypeService;
import com.chinasoft.service.RegionService;
import com.opensymphony.xwork2.ActionContext;

public class HouseSellRentAction {
	private RegionService regionService;
	private HouseTypeService houseTypeService;
	private List<HouseSellRent> list;
	private HttpSession session;
	private File Image; 
	private String ImageFileName; 
	private String ImageContentType; 
	
	private HouseSellRentService houseSellRentService;
	private HouseSellRent houseSellRent;
	private HouseSellSecondhandService houseSellSecondhandService;
	private HouseSellSecondhand houseSellSecondhand;
	private HouseSellEnterpriseService houseSellEnterpriseService;
	private HouseSellEnterprise houseSellEnterprise;
	private HouseBuyRentService houseBuyRentService;
	private HouseBuyRent houseBuyRent;
	private HouseBuyRequestService houseBuyRequestService;
	private HouseBuyRequest houseBuyRequest;
	public HouseSellEnterpriseService getHouseSellEnterpriseService() {
		return houseSellEnterpriseService;
	}

	public void setHouseSellEnterpriseService(
			HouseSellEnterpriseService houseSellEnterpriseService) {
		this.houseSellEnterpriseService = houseSellEnterpriseService;
	}

	public HouseSellEnterprise getHouseSellEnterprise() {
		return houseSellEnterprise;
	}

	public void setHouseSellEnterprise(HouseSellEnterprise houseSellEnterprise) {
		this.houseSellEnterprise = houseSellEnterprise;
	}

	public HouseBuyRentService getHouseBuyRentService() {
		return houseBuyRentService;
	}

	public void setHouseBuyRentService(HouseBuyRentService houseBuyRentService) {
		this.houseBuyRentService = houseBuyRentService;
	}

	public HouseBuyRent getHouseBuyRent() {
		return houseBuyRent;
	}

	public void setHouseBuyRent(HouseBuyRent houseBuyRent) {
		this.houseBuyRent = houseBuyRent;
	}

	public HouseBuyRequestService getHouseBuyRequestService() {
		return houseBuyRequestService;
	}

	public void setHouseBuyRequestService(
			HouseBuyRequestService houseBuyRequestService) {
		this.houseBuyRequestService = houseBuyRequestService;
	}

	public HouseBuyRequest getHouseBuyRequest() {
		return houseBuyRequest;
	}

	public void setHouseBuyRequest(HouseBuyRequest houseBuyRequest) {
		this.houseBuyRequest = houseBuyRequest;
	}


	public HouseSellSecondhandService getHouseSellSecondhandService() {
		return houseSellSecondhandService;
	}

	public void setHouseSellSecondhandService(
			HouseSellSecondhandService houseSellSecondhandService) {
		this.houseSellSecondhandService = houseSellSecondhandService;
	}

	public HouseSellSecondhand getHouseSellSecondhand() {
		return houseSellSecondhand;
	}

	public void setHouseSellSecondhand(HouseSellSecondhand houseSellSecondhand) {
		this.houseSellSecondhand = houseSellSecondhand;
	}


	
	public File getImage() {
		return Image;
	}

	public void setImage(File image) {
		Image = image;
	}

	public String getImageFileName() {
		return ImageFileName;
	}

	public void setImageFileName(String imageFileName) {
		ImageFileName = imageFileName;
	}

	public String getImageContentType() {
		return ImageContentType;
	}

	public void setImageContentType(String imageContentType) {
		ImageContentType = imageContentType;
	}

	
	public HouseTypeService getHouseTypeService() {
		return houseTypeService;
	}

	public void setHouseTypeService(HouseTypeService houseTypeService) {
		this.houseTypeService = houseTypeService;
	}

	
	public RegionService getRegionService() {
		return regionService;
	}

	public void setRegionService(RegionService regionService) {
		this.regionService = regionService;
	}

	
	public HouseSellRentService getHouseSellRentService() {
		return houseSellRentService;
	}

	public void setHouseSellRentService(HouseSellRentService houseSellRentService) {
		this.houseSellRentService = houseSellRentService;
	}

	public HouseSellRent getHouseSellRent() {
		return houseSellRent;
	}

	public void setHouseSellRent(HouseSellRent houseSellRent) {
		this.houseSellRent = houseSellRent;
	}

	public List<HouseSellRent> getList() {
		return list;
	}

	public void setList(List<HouseSellRent> list) {
		this.list = list;
	}

	public String getRentInfo() {
		list = houseSellRentService.getRentInfo();
//		list = houseSellRentService.findAll();
		
		if (list != null) {
			return "success";
		} else {
			return "error";
		}
	}
	
	public List<HouseSellRent> Test() {
		return houseSellRentService.getRentInfo();
	}
	
	public String postNewRent(){
		session = ServletActionContext.getRequest().getSession();
		Users users = (Users)session.getAttribute("users");
		if(users!=null){
		    try{
		    	String realpath = ServletActionContext.getServletContext().getRealPath(
						"/upload");
                if (Image != null) {
					File savefile = new File(new File(realpath), ImageFileName);
					if (!savefile.getParentFile().exists()) {
						savefile.getParentFile().mkdirs();
					}
					FileUtils.copyFile(Image, savefile);
					houseSellRent.setPics(savefile.getPath());	
				}else {
					return "uploadempty";
				}
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
			houseSellRent.getRegion().setRegionId(regionService.getRegionId(houseSellRent.getRegion().getProvince(),houseSellRent.getRegion().getCity(), houseSellRent.getRegion().getCounty()));
		    houseSellRent.getHouseType().setHtypeId(houseTypeService.getHTypeId(houseSellRent.getHouseType().getName()));
		    houseSellRent.setUId(users.getUId());
		    houseSellRent.setHavailability(1);
		    return houseSellRentService.save(houseSellRent);
		} else {
			return "unlog";
		}
	}

	public String postNewSecond(){
		session = ServletActionContext.getRequest().getSession();
		Users users = (Users)session.getAttribute("users");
		if(users!=null){
		    try{
		    	String realpath = ServletActionContext.getServletContext().getRealPath(
						"/upload");
                if (Image != null) {
					File savefile = new File(new File(realpath), ImageFileName);
					if (!savefile.getParentFile().exists()) {
						savefile.getParentFile().mkdirs();
					}
					FileUtils.copyFile(Image, savefile);
					houseSellSecondhand.setPics(savefile.getPath());	
				}else {
					return "uploadempty";
				}
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
			houseSellSecondhand.getRegion().setRegionId(regionService.getRegionId(houseSellSecondhand.getRegion().getProvince(),houseSellSecondhand.getRegion().getCity(), houseSellSecondhand.getRegion().getCounty()));
		    houseSellSecondhand.getHouseType().setHtypeId(houseTypeService.getHTypeId(houseSellSecondhand.getHouseType().getName()));
		    houseSellSecondhand.setUId(users.getUId());
		    houseSellSecondhand.setHavailability(1);
		    return  houseSellSecondhandService.save(houseSellSecondhand);
		} else {
			return "unlog";
		}
	}
	
	public String postNewEnterprise(){
		session = ServletActionContext.getRequest().getSession();
		EnterpriseUsers enterusers = null;
		if(session.getAttribute("user")==null)//个人用户
			return "unlog";
		else {
            if(session.getAttribute("type").toString().equals("0"))
            	return "person_user";
            enterusers = (EnterpriseUsers)session.getAttribute("users");
		    try{
		    	String realpath = ServletActionContext.getServletContext().getRealPath(
						"/upload");
                if (Image != null) {
					File savefile = new File(new File(realpath), ImageFileName);
					if (!savefile.getParentFile().exists()) {
						savefile.getParentFile().mkdirs();
					}
					FileUtils.copyFile(Image, savefile);
					houseSellEnterprise.setPics(savefile.getPath());	
				}else {
					return "uploadempty";
				}
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
			houseSellEnterprise.getRegion().setRegionId(regionService.getRegionId(houseSellEnterprise.getRegion().getProvince(),houseSellEnterprise.getRegion().getCity(), houseSellEnterprise.getRegion().getCounty()));
		    houseSellEnterprise.getHouseType().setHtypeId(houseTypeService.getHTypeId(houseSellEnterprise.getHouseType().getName()));
		    houseSellEnterprise.setEnterpriseUsers(enterusers);
		    houseSellRent.setHavailability(1);
		    return houseSellEnterpriseService.save(houseSellEnterprise);
		} 
	}
	
	public String postNewBuy(){
		session = ServletActionContext.getRequest().getSession();
		Users users = (Users)session.getAttribute("users");
		if(users!=null){
			houseSellSecondhand.getRegion().setRegionId(regionService.getRegionId(houseSellSecondhand.getRegion().getProvince(),houseSellSecondhand.getRegion().getCity(), houseSellSecondhand.getRegion().getCounty()));
		    houseSellSecondhand.getHouseType().setHtypeId(houseTypeService.getHTypeId(houseSellSecondhand.getHouseType().getName()));
		    houseSellSecondhand.setUId(users.getUId());
		    houseSellSecondhand.setHavailability(1);
		    return  houseSellSecondhandService.save(houseSellSecondhand);
		} else {
			return "unlog";
		}
	}
	
	public String postNewBuyRent(){
		session = ServletActionContext.getRequest().getSession();
		Users users = (Users)session.getAttribute("users");
		if(users!=null){
		    try{
		    	String realpath = ServletActionContext.getServletContext().getRealPath(
						"/upload");
                if (Image != null) {
					File savefile = new File(new File(realpath), ImageFileName);
					if (!savefile.getParentFile().exists()) {
						savefile.getParentFile().mkdirs();
					}
					FileUtils.copyFile(Image, savefile);
					houseSellSecondhand.setPics(savefile.getPath());	
				}else {
					return "uploadempty";
				}
		    }catch(Exception e){
		    	e.printStackTrace();
		    }
			houseSellSecondhand.getRegion().setRegionId(regionService.getRegionId(houseSellSecondhand.getRegion().getProvince(),houseSellSecondhand.getRegion().getCity(), houseSellSecondhand.getRegion().getCounty()));
		    houseSellSecondhand.getHouseType().setHtypeId(houseTypeService.getHTypeId(houseSellSecondhand.getHouseType().getName()));
		    houseSellSecondhand.setUId(users.getUId());
		    houseSellSecondhand.setHavailability(1);
		    return  houseSellSecondhandService.save(houseSellSecondhand);
		} else {
			return "unlog";
		}
	}
	
	
	public void closeLayer(){
		HttpServletResponse response = ServletActionContext.getResponse();
		try{
		 PrintWriter out = response.getWriter();
		 out.write("<script type='text/javascript' charset='UTF-8' >alert('发布信息成功!');parent.location.reload();var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index); </script>");
		   	}catch(Exception e){
		   e.printStackTrace();
	   }
	}

}






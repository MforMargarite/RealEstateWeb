package com.chinasoft.action;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.chinasoft.pojo.Users;
import com.chinasoft.service.UsersService;

public class UsersAction {
	private UsersService service; 
	private Users users; 
	private String msg;
	private HttpSession session;

	public UsersService getService() {
		return service;
	}

	public void setService(UsersService service) {
		this.service = service;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}
	
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String login(){
		Users users1 = service.login(users);
		if(users1 != null){
			//users����session
			session = ServletActionContext.getRequest().getSession();
			session.setAttribute("users", users1);
			return "logsuccess";
		}
		else{

			return "error";
		}
	}
	
	public String sellrentlogin(){
		Users users1 = service.login(users);
		if(users1 != null){
			session = ServletActionContext.getRequest().getSession();
			session.setAttribute("users", users1);
			return "sellrentlogsuccess";
		}
		else{

			return "sellrenterror";
		}
	}
	
	/**
	 * �˳���½
	 * �Ƴ�session��users
	 * @return
	 */
	public String signOut(){
		HttpSession session = ServletActionContext.getRequest().getSession();
		session.removeAttribute("users");
		return "signout";
	}
	
	public Users loiginTest(Users users){
		return service.login(users);
	}
	
	public String register(){
		Boolean flag = service.register(users);
		if(flag == true){
			session = ServletActionContext.getRequest().getSession();
			session.setAttribute("users", users);
			return "regsuccess";
		}
		else{
			return "error";
		}
	}
	
	public void closeLayer(){
		HttpServletResponse response = ServletActionContext.getResponse();
		try{
		 PrintWriter out = response.getWriter();
		 out.write("<script charset='UTF-8'>alert('登陆成功');parent.location.reload();var index = parent.layer.getFrameIndex(window.name); parent.layer.close(index); </script>");
	   }catch(Exception e){
		   e.printStackTrace();
	   }
	}
	
	public void logerror(){
		HttpServletResponse response = ServletActionContext.getResponse();
		try{
		 PrintWriter out = response.getWriter();
		 out.write("<script>alert('登录失败');</script>");
	   }catch(Exception e){
		   e.printStackTrace();
	   }
	}
	
}
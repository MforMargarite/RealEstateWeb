package com.chinasoft.service;

public class HouseBuyRentService {

}

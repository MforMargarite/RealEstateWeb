package com.chinasoft.service;

public class HouseBuyRequestService {

}

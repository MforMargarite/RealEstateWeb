package com.chinasoft.service;

import java.util.List;

import com.chinasoft.dao.HouseTypeDAO;
import com.chinasoft.pojo.HouseType;

public class HouseTypeService {
	
	private HouseTypeDAO houseTypeDAO;

	public HouseTypeDAO getHouseTypeDAO() {
		return houseTypeDAO;
	}

	public void setHouseTypeDAO(HouseTypeDAO houseTypeDAO) {
		this.houseTypeDAO = houseTypeDAO;
	}
	
	public int getHTypeId(String name){
		return houseTypeDAO.findIdByName(name);
	}

}

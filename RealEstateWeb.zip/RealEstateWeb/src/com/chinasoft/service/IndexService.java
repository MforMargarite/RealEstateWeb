package com.chinasoft.service;

import java.util.ArrayList;
import java.util.List;

import com.chinasoft.dao.HouseSellEnterpriseDAO;
import com.chinasoft.dao.HouseSellRentDAO;
import com.chinasoft.pojo.HouseSellEnterprise;
import com.chinasoft.pojo.HouseSellRent;

public class IndexService {

	private HouseSellEnterpriseDAO houseSellEnterpriseDAO;
	private HouseSellRentDAO houseSellRentDAO;
	
	public HouseSellEnterpriseDAO getHouseSellEnterpriseDAO() {
		return houseSellEnterpriseDAO;
	}
	public void setHouseSellEnterpriseDAO(
			HouseSellEnterpriseDAO houseSellEnterpriseDAO) {
		this.houseSellEnterpriseDAO = houseSellEnterpriseDAO;
	}
	public HouseSellRentDAO getHouseSellRentDAO() {
		return houseSellRentDAO;
	}
	public void setHouseSellRentDAO(HouseSellRentDAO houseSellRentDAO) {
		this.houseSellRentDAO = houseSellRentDAO;
	}
	
	public List<HouseSellRent> getRentInfo(){
   // 	List<HouseSellRent> list = houseSellRentDao��getRentInfo();
		List<HouseSellRent> list = new ArrayList<HouseSellRent>();
		int length = list.size();
//		return list.subList(length - 4, length); //�������4��
		
		return list.subList(0, 4); //����ǰ4��
	}
	
	public List<HouseSellEnterprise> getSellNewInfo(){
		return null;
		//return houseSellEnterpriseDAO.getSellNewInfo();
	}
	
	
	

}

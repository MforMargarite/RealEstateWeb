import java.util.List;
import java.util.ArrayList;

import com.chinasoft.dao.HouseSellRentDAO;
import com.chinasoft.pojo.HouseSellRent;

public class test {

	public static void main(String[] args) {
//
//		HouseSellRentDAO houseSellRentDAO = new HouseSellRentDAO();
//		
//		List<HouseSellRent> list = houseSellRentDAO.getIndex_HouseSellRents();
//		
//		for(int i = 0; i < list.size(); i++)
//		{
//			System.out.println(list.get(i));
//		}
//		
		
	}
}
